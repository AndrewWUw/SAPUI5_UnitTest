sap.ui.define([
	"test/unit/model/models",
	"test/unit/model/formatter"
], function() {
	"use strict";
});
